# Bootstrap Master IMS Frauenfeld

Based on V 4.x

### Prerequisites

* none


### Author

* **Jean-Pierre Mouret**

### Change Log

###### 04/26/2021
* Updated to Bootstrap 4.6.0
* Updated to Ionicons 5.4.0

###### 11/18/2020
* Updated to Bootstrap 4.5.3
* Introducing Ionicons 5.2.3

###### 06/11/2020
* Updated to Bootstrap 4.5.0

###### 11/12/2019
* Updated to Bootstrap 4.3.1

###### 11/29/2018
* Updated to Bootstrap 4.1.3
* Added jQuery Validation Plugin

### License

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details

### Acknowledgments

* https://getbootstrap.com
* https://realfavicongenerator.net
* https://w3schools.com/bootstrap4
* https://ionicons.com
