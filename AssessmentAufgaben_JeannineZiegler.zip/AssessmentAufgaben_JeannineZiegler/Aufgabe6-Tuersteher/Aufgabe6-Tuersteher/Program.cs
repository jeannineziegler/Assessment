﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aufgabe6_Tuersteher
{
    class Program
    {
        public static int dateFashion(int you, int date)
        {
            int answer = 1;
            
            if(you >= 8 || date >= 8)
            {
                answer = 2;
            }
            else if(you <= 2 || date <= 2)
            {
                answer = 0;
            }

            return answer;
        }

        static void Main(string[] args)
        {
            Random rand = new Random();
            int you = rand.Next(1, 10);
            Console.WriteLine("You: " + you);
            int date = rand.Next(1, 10);
            Console.WriteLine("Date: " + date);
            int rating = dateFashion(you, date);
            string responds;
            if(rating == 2)
            {
                responds = "Ja";
            }
            else if(rating == 1)
            {
                responds = "Vielleicht";
            }
            else
            {
                responds = "Nein";
            }
            Console.WriteLine("Türsteher 3000-KL sagt: " + responds);
            Console.ReadLine();
        }
    }
}
