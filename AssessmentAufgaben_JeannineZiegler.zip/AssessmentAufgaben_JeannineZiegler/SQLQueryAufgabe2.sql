CREATE DATABASE databasename;

Create table TBenutzer( NutzNickname varchar(20) primary key,
						NutzName varchar(20),
                        NutzFollower int unsigned);
                        
Create table TAusfluege(AusflugID int unsigned auto_increment primary key,
						AusflugName varchar(20),
                        AusflugBeschreibung text);
                        