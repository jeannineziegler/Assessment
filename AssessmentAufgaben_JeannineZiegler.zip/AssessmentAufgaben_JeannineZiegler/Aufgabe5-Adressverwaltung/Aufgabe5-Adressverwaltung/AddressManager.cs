﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aufgabe5_Adressverwaltung
{
    interface AddressManagerInterface
    {
        private void addAddress(Address address);
        protected void printAddresses();

        //?? noch nie gehabt, auch nichts sinnvolles im Internet gefunden + keine Zeit mehr zu fragen
        
    } 
    class AddressManager
    {

    }
}
