﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aufgabe5_Adressverwaltung
{
    class HomeAddress
    {
        private String street;
        HomeAddress(String street)
        {
            this.street = street;
        }

        public void PrintAdress()
        {
            Console.WriteLine("Heimadresse");
            Console.WriteLine(street);
            Console.WriteLine();

        }
    }
}
