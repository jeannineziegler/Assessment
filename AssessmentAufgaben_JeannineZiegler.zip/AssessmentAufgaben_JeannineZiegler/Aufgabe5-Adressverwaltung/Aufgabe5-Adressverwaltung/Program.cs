﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aufgabe5_Adressverwaltung
{
    class Program
    {
        static void Main(string[] args)
        {
            AddressManager m = new AddressManager();
            m.addAddress(new BusinessAddress("Astrasse"));
            m.addAddress(new HomeAddress("Bstrasse"));
            m.addAddress(new BusinessAddress("Cstrasse"));
            m.addAddress(new HomeAddress("Dstrasse"));
            m.printAddresses();
        }
    }
}
