﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aufgabe5_Adressverwaltung
{
    class BusinessAddress
    {
        private String street;
        BusinessAddress(String street)
        {
            this.street = street;
        }

        public void PrintAdress()
        {
            Console.WriteLine("Geschäftsadresse");
            Console.WriteLine(street);
            Console.WriteLine();

        }
    }
}
