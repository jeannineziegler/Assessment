<?php

function countWords($str) {
    $str2 = strtolower($str);
    $str3 = preg_replace('/[^a-zäöü0-9\s]/i', '', $str2);
    $arr1 = explode(' ', $str3,);
    $arr2 = array_count_values($arr1);
    return $arr2;
}

fputs(STDOUT, "Geben Sie einen kurzen Text ein: \n");
$text = trim(fgets(STDIN));
$result = countWords($text);
echo "Anzahl Wörter: " . count($result) . "\n";
arsort($result);
foreach ($result as $name => $wert) {
    if ($name == "") {
        continue;
    } else {
        echo "$name: $wert";
        echo "\n";
    }
}


